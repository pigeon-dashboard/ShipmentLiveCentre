// Azure Static Web Apps — Vessel AIS Proxy
// Replaces Netlify Function: /.netlify/functions/vessel
// Endpoint: /api/vessel?imo=9449876
// Set MST_API_KEY in Azure Static Web Apps → Configuration → Application Settings

module.exports = async function (context, req) {
  const CORS = {
    'Access-Control-Allow-Origin':  '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    context.res = { status: 200, headers: CORS, body: '' };
    return;
  }

  const API_KEY = process.env.MST_API_KEY;
  if (!API_KEY) {
    context.res = {
      status: 500, headers: CORS,
      body: JSON.stringify({ status: 'error', message: 'MST_API_KEY not configured in Azure App Settings' })
    };
    return;
  }

  const { imo, mmsi, name } = req.query;
  if (!imo && !mmsi && !name) {
    context.res = {
      status: 400, headers: CORS,
      body: JSON.stringify({ status: 'error', message: 'Provide imo, mmsi, or name parameter' })
    };
    return;
  }

  let url;
  if (name) {
    url = `https://api.myshiptracking.com/api/v2/vessel/search?name=${encodeURIComponent(name)}`;
  } else {
    const param = imo ? `imo=${imo}` : `mmsi=${mmsi}`;
    url = `https://api.myshiptracking.com/api/v2/vessel?${param}&response=extended`;
  }

  context.log(`[vessel-proxy] Fetching: ${url}`);

  try {
    const resp = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'x-api-key': API_KEY,
        'Accept': 'application/json',
        'User-Agent': 'ShipmentCommandCentre/2.0'
      }
    });

    const text = await resp.text();
    context.log(`[vessel-proxy] Status: ${resp.status}`);

    let data;
    try { data = JSON.parse(text); } catch (e) { data = { raw: text }; }

    context.res = { status: resp.status, headers: CORS, body: JSON.stringify(data) };

  } catch (err) {
    context.log.error('[vessel-proxy] Error:', err.message);
    context.res = {
      status: 500, headers: CORS,
      body: JSON.stringify({ status: 'error', message: err.message })
    };
  }
};
